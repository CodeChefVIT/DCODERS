<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="assets/css/main.css" />
    <title>Hospital</title>
</head>
<body class="left-sidebar is-preload">
                <div id="page-wrapper">
        
                    <!-- Header -->
                        <div id="header">
        
                            <!-- Inner -->
                                <div class="inner">
                                    <header>
                                        <h1><a href="index.html" id="logo">Claim your Hospital payment.</a></h1>
                                    </header>
                                </div>
        
                            <!-- Nav -->
                         </div>
        
                    <!-- Main -->
                        <div class="wrapper style1">
        
                            <div class="container">
                                <div class="row gtr-200">
                                    <div class="col-4 col-12-mobile" id="sidebar">
                                        <hr class="first" />
                                        <section>
                                            <header>
                                                <h3><a href="#">Apply  for reimbursement</a></h3>
                                            </header>
                                            <p>
                                                Apply for the medical reimbursement and get you money back just 
                                                by entering the transaction id.

                                            </p>
                                            <footer>
                                                    <form method="POST" action="Apply.php">
                                                            <button type="submit">Apply</button>
                                                    </form>
                                            </footer>
                                        </section>
                                        <hr />
                                        

                                        <section>
                                            
                                            <header>
                                                <h3><a href="#"> Disease Predictor</a></h3>
                                            </header>
                                            <p>
                                                Predict the disease you are suffering from by 
                                                selecting the symptoms seen.                                            </p>
                                            <!--

                                            <div class="row gtr-50">
                                                <div class="col-4">
                                                    <a href="#" class="image fit"><img src="images/pic10.jpg" alt="" /></a>
                                                </div>
                                                <div class="col-8">
                                                    <h4>Nibh sed cubilia</h4>
                                                    <p>
                                                        Amet nullam fringilla nibh nulla convallis tique ante proin.
                                                    </p>
                                                </div>
                                                <div class="col-4">
                                                    <a href="#" class="image fit"><img src="images/pic11.jpg" alt="" /></a>
                                                </div>
                                                <div class="col-8">
                                                    <h4>Proin sed adipiscing</h4>
                                                    <p>
                                                        Amet nullam fringilla nibh nulla convallis tique ante proin.
                                                    </p>
                                                </div>
                                                <div class="col-4">
                                                    <a href="#" class="image fit"><img src="images/pic12.jpg" alt="" /></a>
                                                </div>
                                                <div class="col-8">
                                                    <h4>Lorem feugiat magna</h4>
                                                    <p>
                                                        Amet nullam fringilla nibh nulla convallis tique ante proin.
                                                    </p>
                                                </div>
                                                <div class="col-4">
                                                    <a href="#" class="image fit"><img src="images/pic13.jpg" alt="" /></a>
                                                </div>
                                                <div class="col-8">
                                                    <h4>Sed tempus fringilla</h4>
                                                    <p>
                                                        Amet nullam fringilla nibh nulla convallis tique ante proin.
                                                    </p>
                                                </div>
                                                <div class="col-4">
                                                    <a href="#" class="image fit"><img src="images/pic14.jpg" alt="" /></a>
                                                </div>
                                                <div class="col-8">
                                                    <h4>Malesuada fermentum</h4>
                                                    <p>
                                                        Amet nullam fringilla nibh nulla convallis tique ante proin.
                                                    </p>
                                                </div>
                                            </div>-->
                                            <footer>
                                                    <form method="POST" action="predict.php">
                                                            <button type="submit">Predict</button>
                                                    </form>
                                            </footer>
                                        </section>
                                    </div>
                                    <div class="col-8 col-12-mobile imp-mobile" id="content">
                                        <article id="main">
                                            <header>
                                                <h2><a href="#">Pay back</a></h2>
                                                <p>
                                                    Get your payment after a month </p>
                                            </header>
                                            <a href="#" class="image featured"><img src="images/hospital.jpg" alt="" /></a>
                                            <!--

                                            <p>
                                                Commodo id natoque malesuada sollicitudin elit suscipit. Curae suspendisse mauris posuere accumsan massa
                                                posuere lacus convallis tellus interdum. Amet nullam fringilla nibh nulla convallis ut venenatis purus
                                                lobortis. Auctor etiam porttitor phasellus tempus cubilia ultrices tempor sagittis. Nisl fermentum
                                                consequat integer interdum integer purus sapien. Nibh eleifend nulla nascetur pharetra commodo mi augue
                                                interdum tellus. Ornare cursus augue feugiat sodales velit lorem. Semper elementum ullamcorper lacinia
                                                natoque aenean scelerisque vel lacinia mollis quam sodales congue.
                                            </p>
                                            <section>
                                                <header>
                                                    <h3>Ultrices tempor sagittis nisl</h3>
                                                </header>
                                                <p>
                                                    Nascetur volutpat nibh ullamcorper vivamus at purus. Cursus ultrices porttitor sollicitudin imperdiet
                                                    at pretium tellus in euismod a integer sodales neque. Nibh quis dui quis mattis eget imperdiet venenatis
                                                    feugiat. Neque primis ligula cum erat aenean tristique luctus risus ipsum praesent iaculis. Fermentum elit
                                                    fringilla consequat dis arcu. Pellentesque mus tempor vitae pretium sodales porttitor lacus. Phasellus
                                                    egestas odio nisl duis sociis purus faucibus morbi. Eget massa mus etiam sociis pharetra magna.
                                                </p>
                                                <p>
                                                    Eleifend auctor turpis magnis sed porta nisl pretium. Aenean suspendisse nulla eget sed etiam parturient
                                                    orci cursus nibh. Quisque eu nec neque felis laoreet diam morbi egestas. Dignissim cras rutrum consectetur
                                                    ut penatibus fermentum nibh erat malesuada varius.
                                                </p>
                                            </section>
                                            <section>
                                                <header>
                                                    <h3>Augue euismod feugiat tempus</h3>
                                                </header>
                                                <p>
                                                    Pretium tellus in euismod a integer sodales neque. Nibh quis dui quis mattis eget imperdiet venenatis
                                                    feugiat. Neque primis ligula cum erat aenean tristique luctus risus ipsum praesent iaculis. Fermentum elit
                                                    ut nunc urna volutpat donec cubilia commodo risus morbi. Lobortis vestibulum velit malesuada ante
                                                    egestas odio nisl duis sociis purus faucibus morbi. Eget massa mus etiam sociis pharetra magna.
                                                </p>
                                            </section>-->
                                        </article>
                                    </div>
                                </div>
    
    

    <br><br>
    <!--<div class = "row">
        <div class = " col-12">
            <form method="POST" action="Apply.php">
                <button type="submit">Apply</button>
            </form>
            <form method="POST" action="predict.php">
                <button type="submit">Disease Predict</button>
            </form>
        </div>
    </div>-->




            <script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
</body>
</html>